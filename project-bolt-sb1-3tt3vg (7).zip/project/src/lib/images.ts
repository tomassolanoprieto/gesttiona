export const images = {
  logo: '/images/logo-gestiona.png',
  hero: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?ixlib=rb-1.2.1&auto=format&fit=crop&w=2850&q=85',
  about: '/images/Foto 2.jpg',
  whyChooseUs: '/images/Foto 3.jpg',
  services: '/images/Foto 4.jpg'
};