import CMS from 'decap-cms-app';
import { es } from 'decap-cms-locales';
import { config } from './config';

CMS.registerLocale('es', es);
CMS.init({ config });