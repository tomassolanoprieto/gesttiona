export const contactInfo = {
  email: 'gesttiona.mcb@gmail.com',
  phone: '685 740 740',
  address: 'Calle L\'Entrada 40 Bajo, Benaguacil, Valencia, 46180',
  officeHours: 'Lunes a Viernes: 9:00h-14:00h y 15:00h-19:00h',
  businessHours: 'Lunes a Viernes: 9:00h-13:00h'
};