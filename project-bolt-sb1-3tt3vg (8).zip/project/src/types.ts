export interface ContactInfo {
  email: string;
  phone: string;
  address: string;
  officeHours: string;
  businessHours: string;
}